<?php 

// CONTACT FORM RECIPIENT MAIL SETUP
define( 'CONTACT_FORM_RECIPIENT', 'mlimonbd@gmail.com');


// MAILCHIMP SETUP KEY AND ID
define( 'MAILCHIMP_API_KEY', '56caad6a91396739678186d0c0b62fa7-us10'); // example -> 56caad6a91396739678186d0c0b62fa7-us10
define( 'MAILCHIMP_LIST_ID', '0819261091'); // example -> 0819261091

//replace us10 with your actual datacenter
define( 'MAILCHIMP_SUBMIT_URL', 'http://us10.api.mailchimp.com/1.3/?method=listSubscribe'); 
// change only us10 if defferent of your mailchimp submit url actual datacenter !!
// see in mailchimp api key last string or see in your admin url example -> http://goo.gl/Lxx9Op


