<?php
include_once('config.php');

$name = strip_tags(trim($_POST["senderName"]));
$name = str_replace(array("\r","\n"),array(" "," "),$name);
$email = filter_var(trim($_POST["senderEmail"]), FILTER_SANITIZE_EMAIL);
$send_subject = trim($_POST["senderSubject"]);
$send_message = trim($_POST["senderMessage"]);

// Check that data was sent to the mailer.
if ( empty($name) OR empty($send_subject) OR empty($send_message) OR !filter_var($email, FILTER_VALIDATE_EMAIL)) {
    echo "Oops! There was a problem with your submission. Please complete the form and try again.";
    exit;
}


$subject = $_POST['senderSubject'] . ' : Another Contact Form'; // Subject of your email
$recipient = CONTACT_FORM_RECIPIENT;  //Recipient's E-mail

$headers  = 'MIME-Version: 1.0' . "\r\n";
$headers .= "From: " . $_POST['senderEmail'] . "\r\n"; // Sender's E-mail
$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

$message .= 'Name: ' . $_POST['senderName'] . "<br />";
$message .= 'Email: ' . $_POST['senderEmail'] . "<br />";
$message .= 'Subject: ' . $_POST['senderSubject'] . "<br /><br />";
$message .= 'Message Body: ' . $_POST['senderMessage'] . "<br />";

if (mail($recipient, $subject, $message, $headers))
{
    // Transfer the value 'sent' to ajax function for showing success message.
    echo ' Your message has been sent successfully';
}
else
{
    // Transfer the value 'failed' to ajax function for showing error message.
    echo 'Could not send mail!';
}
