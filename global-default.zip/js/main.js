/*=============================================================
================ Global by PIXIEFY ============================
===============================================================

	GLOBAL - The coming soon ultimate
	@Author		   Mohammad Limon / pixiefy team

	TABLE OF CONTENTS
	---------------------------
	 1. PRELOADER
	 2. CUSTOM LOAD INIT
	 3. CUSTOM READY INIT
	 4. SCROLLBAR
	 5. COUNDOWN 
	 6. TOOLTIP
	 7. POPUP
	 8. GOOGLE MAP
	 9. SUBSCRIPTION FORM 
	 10.CONTACT FORM 
	 11.CUSTOM SLIDESHOW 

==============================================================*/



/*--------------------------------------------------------------
	1. GLOBAL PRELOADER INIT
--------------------------------------------------------------*/
$( window ).load(function() {
	$(".global_default_preloader").delay(600).fadeOut(500);
	$('body').css({ 'overflow' : 'visible'});
});


/*--------------------------------------------------------------
	2. GLOBAL LOAD INIT SCRIPT
--------------------------------------------------------------*/
$(window).load(function(){
	
	$(function(){
		$.fn.center = function () {
			this.css("position","absolute");
			this.css("top", ( $(window).height() - this.height() ) / 2  + "px");
			this.css("left", ( $(window).width() - this.width() ) / 2 + "px");
			return this;
		}
		$.fn.centerx = function () {
			this.css("position","absolute");
			this.css("top", ( $(window).height() - this.height() ) / 2  + "px");
			return this;
		}
		
		$(".global-all-features").centerx(); 
		$(".global-welcome-message").center(); 
		$('.single-scrollbar-popup').height($(window).height());
		$('#map_canvas').height($(window).height());

		$(window).resize(function(){
		   $(".global-welcome-message").centerx();
		   $(".global-all-features").center();
		   $('.single-scrollbar-popup').height($(window).height());
		   $('#map_canvas').height($(window).height());
		});
	});

});

$(window).load(function(){

	setTimeout(function(){
	   $(".global-welcome-message > h2").removeClass('DoInVisible').addClass('DoVisible fadeInDown animated');
	},2000);

	setTimeout(function(){
	   $(".global-welcome-message > h2").addClass('borderWidth');
	},3000);

	setTimeout(function(){
	   $(".global-welcome-message > h2").removeClass('fadeInDown animated').addClass('fadeOut animated');
	},6000);

	setTimeout(function(){
	   $(".global-default-invisible-ul").addClass('appear-global-social-ul');
	},6500);

	setTimeout(function(){
	   $("#countdown_dashboard .global-timer").removeClass('DoInVisible').addClass('DoVisible fadeInDown animated');
	},6500);

	setTimeout(function(){
	   $("#logoTitle").removeClass('DoInVisible').addClass('DoVisible fadeInDown animated');
	},6500);

	setTimeout(function(){
	   $(".global-subscription_form").removeClass('DoInVisible').addClass('DoVisible fadeInDown animated');
	},6500);

	setTimeout(function(){
	   $(".siteDescriptions").removeClass('DoInVisible').addClass('DoVisible fadeInDown animated');
	},6500);

	setTimeout(function(){
	   $(".global-menu_bar_main").addClass('liaAnimated');
	},7000);

	setTimeout(function(){
	   $("#logoTitle").addClass('borderOpecity');
	},8500);

});


/*--------------------------------------------------------------
	3. GLOBAL WINDOW READY INIT SCRIPT
--------------------------------------------------------------*/
$(document).ready(function ($) {
  "use strict";
  

});


/*--------------------------------------------------------------
	4. GLOBAL SCROLLBAR INIT
--------------------------------------------------------------*/
$(document).ready(function ($) {
  "use strict";
  $('.single-scrollbar-popup').perfectScrollbar();
});


/*--------------------------------------------------------------
	5. GLOBAL COUNDOWN INIT
--------------------------------------------------------------*/
$(document).ready(function() {
	$('#countdown_dashboard').countDown({
		targetDate: {
			'day': 		24,
			'month': 	12,
			'year': 	2015,
			'hour': 	11,
			'min': 		13,
			'sec': 		0
		},
		omitWeeks: true
	});

});

/*--------------------------------------------------------------
	6. GLOBAL TOOLTIP INIT
--------------------------------------------------------------*/
$(function () {
  $('[data-toggle="tooltip"]').tooltip()
});


/*--------------------------------------------------------------
	7. GLOBAL POPUP INIT
--------------------------------------------------------------*/
$(document).ready(function() {

	$('#global-about-us').popup({
		onopen: function() {
		    $('#golbal-main-content, .global-subscription_form, #global-top-social-medias').hide();
		},
		onclose: function() {
		    $('#golbal-main-content, .global-subscription_form, #global-top-social-medias').delay(1000).slideDown(1000);
		},
		opacity: 0.2,
		blur: true,
		focusdelay: 400,
		transition: 'all 1.2s'
	});
	$('#global-contact-us').popup({
		onopen: function() {
		    $('#golbal-main-content, .global-subscription_form, #global-top-social-medias').hide();
		},
		onclose: function() {
		    $('#golbal-main-content, .global-subscription_form, #global-top-social-medias').delay(1000).slideDown(1000);
		},
		opacity: 0.2,
		focusdelay: 400,
		transition: 'all 1.2s'
	});
	$('#global-our-location').popup({
		onopen: function() {
		    $('#golbal-main-content, .global-subscription_form, #global-top-social-medias').hide();
		},
		onclose: function() {
		    $('#golbal-main-content, .global-subscription_form, #global-top-social-medias').delay(1000).slideDown(1000);
		},
		opacity: 0.2,
		blur: true,
		focusdelay: 400,
		transition: 'all 1.2s'
	});
	$('#global-our-services').popup({
		onopen: function() {
		    $('#golbal-main-content, .global-subscription_form, #global-top-social-medias').hide();
		},
		onclose: function() {
		    $('#golbal-main-content, .global-subscription_form, #global-top-social-medias').delay(1000).slideDown(1000);
		},
		opacity: 0.2,
		blur: true,
		focusdelay: 400,
		transition: 'all 1.2s'
	});

});



/*--------------------------------------------------------------
	8. GLOBAL GOGLE MAP INIT
--------------------------------------------------------------*/
function loadGoogle() {
  var  map = new google.maps.Map(document.getElementById("map_canvas"), {
      center: new google.maps.LatLng(40.6700, -73.9400),
      zoom: 11,
      scrollwheel: false,
      navigationControl: false,
      mapTypeControl: false,
      scaleControl: false,
      draggable: true,
      disableDefaultUI: true,
      styles: [{"featureType":"all","elementType":"all","stylers":[{"saturation":-100},{"gamma":0.5}]}],
      mapTypeId: 'roadmap'
  });
  var marker = new google.maps.Marker({
    position: new google.maps.LatLng(40.6700, -73.9400),
    map: map,
    title: 'Global CommingSoon'
  });
  var contentString = '<div id="content">' +
      '<div id="myDiv">' +
      '</div>' +
      '<h3 id="heading">COLORADO</h3>' +
      '<div id="bodyContent">' +
      '<p>PIXIEFY THEMES ' +
      '2746 Scheuvront Drive ' +
      '<a href="#">www.pixiefy.com </a>' +
      'Denver, CO 80202 . </p>' +
      '</div>' +
      '</div>';

  var infowindow = new google.maps.InfoWindow({
      content: contentString,
      maxWidth: 280
  });

  marker.setAnimation(google.maps.Animation.BOUNCE);
  setTimeout(function(){ marker.setAnimation(null); }, 750);  //time it takes for one bounce   

  google.maps.event.addListener(marker, 'click', function () {
      infowindow.open(map, marker);
  });


}

$(document).ready(function(){
  var element =  $(".global-our-location_open");

  $( element ).click(function(){
    loadGoogle();
  });

});


/*--------------------------------------------------------------
	9. GLOBAL SUBSCRIPTION FORM INIT
--------------------------------------------------------------*/
$(document).ready(function() {
	$('#global-subscribe').submit(function() {

	if (!valid_email_address($("#s-email").val()))
	{	
		$('.loading_submission').hide();
		$('.submission_completed').hide();
		$('.submission_error').show();
		$('#submitButton').removeClass('redSignal greenSignal').addClass('redSignal');
		$(".global-subscription-alert-message").html('<span class="alert_message">The email address you entered was invalid.</span>');
	}
	else
	{	
		$('.loading_submission').show();
		$('.submission_completed').hide();
		$('.submission_error').hide();
		$(".global-subscription-alert-message").html('');
		$.ajax({
		url: $(this).attr('action'),
		data: $('#global-subscribe').serialize(),
		type: 'POST',
		success: function(msg) {
			$("#s-email").val("");
			$('.loading_submission').hide();
			$('.submission_completed').show();
			$('#submitButton').removeClass('redSignal').addClass('greenSignal');
			$(".global-subscription-alert-message").html('<span class="alert_message">You have successfully subscribed to our mailing list.</span>');
		},
		error: function(msg) {
			$("#s-email").val("");
			$('.loading_submission').hide();
			$('.submission_completed').hide();
			$('.submission_error').show();
			$('#submitButton').removeClass('greenSignal').addClass('redSignal');
			$(".global-subscription-alert-message").html('<span class="alert_message">An error found.</span>');
		}
		});
	}
	 
	return false;
	});
});

function valid_email_address(email) {
	var pattern = new RegExp(/^[+a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,4}$/i);
	return pattern.test(email);
} 


/*--------------------------------------------------------------
	10. GLOBAL CONTACT FORM INIT
--------------------------------------------------------------*/
$(document).ready(function(){
    $('#global-senderSubmit').click(function(e){
        
        //Stop form submission & check the validation
        e.preventDefault();
        
        // Variable declaration
        var error 			= false,
        	name 			= $('#global-senderName').val(),
        	email 			= $('#global-senderEmail').val(),
        	subject 		= $('#global-senderSubject').val(),
        	message 		= $('#global-senderMessage').val(),
        	mail_fail 		= $('#mail_fail'),
        	mail_success 	= $('#mail_success'),
        	submit_btn 	= $('#global-senderSubmit');
        
     	// Form field validation
        if(name.length == 0){
            var error = true;
            $('#global-senderName').addClass('filed_error');
        }else{
            $('#global-senderName').removeClass('filed_error');
        }
        if(email.length == 0 || email.indexOf('@') == '-1'){
            var error = true;
            $('#global-senderEmail').addClass('filed_error');
        }else{
            $('#global-senderEmail').removeClass('filed_error');
        }
        if(subject.length == 0){
            var error = true;
            $('#global-senderSubject').addClass('filed_error');
        }else{
            $('#global-senderSubject').removeClass('filed_error');
        }
        if(message.length == 0){
            var error = true;
            $('#global-senderMessage').addClass('filed_error');
        }else{
            $('#global-senderMessage').removeClass('filed_error');
        }

        $('input').bind("change paste keyup", function() {
        	$(this).removeClass('filed_error');
        });
        $('textarea').bind("change paste keyup", function() {
        	$(this).removeClass('filed_error');
        });
        if (error == true) {
        	$(mail_fail).fadeIn(500);
        	$(this).attr({'value' : 'Send Message' });
        };

        // If there is no validation error, next to process the mail function
        if(error == false){
           // Disable submit button just after the form processed 1st time successfully.
            $(this).attr({'value' : 'Sending...' });
            $(mail_success).hide();
            $(mail_fail).hide();
            $.ajax({
			url: $(this).closest('form').attr('action'),
			data: $(this).closest('form').serialize(),
			type: 'POST',
			success: function() {
				$(mail_success).fadeIn(500);
				$('.input_global').val('');
				$('.textarea_global').val('');
				$('.filed_error').removeClass('filed_error');
				$(submit_btn).attr({'value' : 'Send Message' });
			},
			error: function() {
				$(mail_fail).fadeIn(500);
				$(submit_btn).attr({'value' : 'Send Message' });
			}
			});


        }
    });    
});


/*--------------------------------------------------------------
	11. GLOBAL BACKGROUND SLIDESHOW INIT
--------------------------------------------------------------*/
$( function() {
	$.vegas( 'slideshow', {
		delay: 8000,
		backgrounds: [
			{ src: 'images/slide/4.jpg', fade: 4000 },
			{ src: 'images/slide/3.jpg', fade: 4000 },
			{ src: 'images/slide/2.jpg', fade: 4000 },
			{ src: 'images/slide/1.jpg', fade: 4000 }
		]
	} )( 'overlay' );
} );